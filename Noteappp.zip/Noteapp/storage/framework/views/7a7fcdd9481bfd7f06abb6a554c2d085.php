<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Procès-Verbal - <?php echo e($filiere->nom); ?> - <?php echo e($classe->nom); ?> - <?php echo e($semestre->nom); ?></title>
    <style>
        @page {
            margin: 1.5cm;
        }
        body {
            font-family: 'DejaVu Sans', Arial, sans-serif;
            font-size: 12px;
            line-height: 1.4;
            color: #333;
        }
        .header {
            text-align: center;
            border-bottom: 3px solid #2c3e50;
            padding-bottom: 15px;
            margin-bottom: 25px;
        }
        .university {
            font-size: 18px;
            font-weight: bold;
            color: #2c3e50;
        }
        .faculty {
            font-size: 14px;
            color: #7f8c8d;
            margin-bottom: 5px;
        }
        .title {
            font-size: 20px;
            font-weight: bold;
            color: #2980b9;
            margin: 15px 0;
            text-transform: uppercase;
        }
        .info-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 25px;
            background-color: #f8f9fa;
            border: 1px solid #dee2e6;
        }
        .info-table th, .info-table td {
            padding: 8px 12px;
            border: 1px solid #dee2e6;
            text-align: left;
        }
        .info-table th {
            background-color: #e9ecef;
            font-weight: bold;
            width: 25%;
        }
        .results-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            font-size: 11px;
        }
        .results-table thead {
            background-color: #2c3e50;
            color: white;
        }
        .results-table th, .results-table td {
            padding: 8px 10px;
            border: 1px solid #dee2e6;
            text-align: center;
        }
        .results-table tbody tr:nth-child(even) {
            background-color: #f8f9fa;
        }
        .results-table tbody tr:hover {
            background-color: #e9ecef;
        }
        .status-admis {
            color: #27ae60;
            font-weight: bold;
        }
        .status-rattrapage {
            color: #f39c12;
            font-weight: bold;
        }
        .status-ajourne {
            color: #e74c3c;
            font-weight: bold;
        }
        .footer {
            margin-top: 40px;
            padding-top: 15px;
            border-top: 1px solid #dee2e6;
            text-align: center;
            font-size: 10px;
            color: #7f8c8d;
        }
        .signature {
            margin-top: 30px;
            text-align: right;
        }
        .signature-line {
            border-top: 1px solid #333;
            width: 300px;
            margin-left: auto;
            margin-top: 40px;
        }
        .page-break {
            page-break-before: always;
        }
        .statistics {
            margin-top: 20px;
            padding: 15px;
            background-color: #f8f9fa;
            border-left: 4px solid #2980b9;
        }
        .statistics h4 {
            margin-top: 0;
            color: #2c3e50;
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="university">Université des Sciences et Technologies</div>
        <div class="faculty">Faculté des Sciences de l'Ingénieur</div>
        <div class="faculty">Département d'Informatique</div>
        <div class="title">PROCÈS-VERBAL DES NOTES</div>
    </div>

    <table class="info-table">
        <tr>
            <th>Filière</th>
            <td><?php echo e($filiere->nom_Filiere); ?></td>
            <th>Classe</th>
            <td><?php echo e($classe->lib_Classe); ?></td>
        </tr>
        <tr>
            <th>Semestre</th>
            <td>Semestre <?php echo e($semestre->numero); ?></td>
            <th>Date de génération</th>
            <td><?php echo e($dateGeneration); ?></td>
        </tr>
        <tr>
            <th>Nombre d'étudiants</th>
            <td><?php echo e(count($resultats)); ?></td>
            <th>Nombre d'évaluations</th>
            <td><?php echo e($evaluations->count()); ?></td>
        </tr>
    </table>

    <h3>Liste des évaluations</h3>
    <ul>
        <?php $__currentLoopData = $evaluations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evaluation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($evaluation->type_Evaluation); ?> - <?php echo e($evaluation->date_Evaluation->format('d/m/Y')); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>

    <h3>Résultats des étudiants</h3>
    <table class="results-table">
        <thead>
            <tr>
                <th>Rang</th>
                <th>Matricule</th>
                <th>Nom et Prénom</th>
                <?php $__currentLoopData = $evaluations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evaluation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <th><?php echo e(substr($evaluation->type_Evaluation, 0, 10)); ?></th>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <th>Moyenne</th>
                <th>Statut</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $resultats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $resultat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($index + 1); ?></td>
                    <td><?php echo e($resultat['etudiant']->matricule ?? 'N/A'); ?></td>
                    <td><?php echo e($resultat['etudiant']->nom); ?> <?php echo e($resultat['etudiant']->prenom); ?></td>
                    <?php $__currentLoopData = $evaluations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evaluation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $note = $resultat['notes']->where('id_Evaluation', $evaluation->id_Evaluation)->first();
                        ?>
                        <td><?php echo e($note ? $note->valeur : 'Abs'); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <td><strong><?php echo e($resultat['moyenne']); ?></strong></td>
                    <td class="status-<?php echo e(strtolower($resultat['statut'])); ?>"><?php echo e($resultat['statut']); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <div class="statistics">
        <h4>Statistiques de la promotion</h4>
        <?php
            $admis = collect($resultats)->where('statut', 'Admis')->count();
            $rattrapage = collect($resultats)->where('statut', 'Rattrapage')->count();
            $ajourne = collect($resultats)->where('statut', 'Ajourné')->count();
            $total = count($resultats);
            $pourcentageAdmis = $total > 0 ? round(($admis / $total) * 100, 1) : 0;
        ?>
        <p><strong>Admis:</strong> <?php echo e($admis); ?> (<?php echo e($pourcentageAdmis); ?>%) | 
           <strong>Rattrapage:</strong> <?php echo e($rattrapage); ?> | 
           <strong>Ajourné:</strong> <?php echo e($ajourne); ?> | 
           <strong>Total:</strong> <?php echo e($total); ?></p>
        <p><strong>Moyenne générale:</strong> <?php echo e($total > 0 ? round(collect($resultats)->avg('moyenne'), 2) : 0); ?></p>
    </div>

    <div class="signature">
        <p>Le Chef de Département,</p>
        <div class="signature-line"></div>
        <p>Dr. Martin Leroy</p>
        <p>Chef du Département d'Informatique</p>
        <p>Date: <?php echo e($dateGeneration); ?></p>
    </div>

    <div class="footer">
        <p>Document généré électroniquement - Université des Sciences et Technologies</p>
        <p>Ce document a une valeur officielle</p>
    </div>
</body>
</html><?php /**PATH D:\Ecole\Niveau 3\semestre3\si\gestionNote\Noteapp\resources\views/departement/pv_template.blade.php ENDPATH**/ ?>